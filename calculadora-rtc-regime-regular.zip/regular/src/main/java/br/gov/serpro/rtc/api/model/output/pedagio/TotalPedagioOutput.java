/*
 * Versão de Homologação/Testes
 */
package br.gov.serpro.rtc.api.model.output.pedagio;

import static br.gov.serpro.rtc.api.model.output.pedagio.TributoTotalPedagioOutput.totalizaCbs;
import static br.gov.serpro.rtc.api.model.output.pedagio.TributoTotalPedagioOutput.totalizaIbsEstadual;
import static br.gov.serpro.rtc.api.model.output.pedagio.TributoTotalPedagioOutput.totalizaIbsMunicipal;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import br.gov.serpro.rtc.api.model.SerializationVisibility;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.extern.jackson.Jacksonized;
import lombok.Value;

/**
 * Saída que consolida os totais de CBS e IBS apurados no cálculo tributário de
 * pedágio. Agrupa os valores finais de cada tributo após a apuração dos
 * diversos trechos considerados na operação.
 */
@Value
@Builder
@Jacksonized
@JsonInclude(Include.NON_NULL)
public final class TotalPedagioOutput implements SerializationVisibility {

    @Schema(name = "cbsTotal", description = "Total de CBS apurado")
    private final TributoTotalPedagioOutput cbsTotal;

    @Schema(name = "ibsEstadualTotal", description = "Total de IBS Estadual apurado")
    private final TributoTotalPedagioOutput ibsEstadualTotal;

    @Schema(name = "ibsMunicipalTotal", description = "Total de IBS Municipal apurado")
    private final TributoTotalPedagioOutput ibsMunicipalTotal;

    public static TotalPedagioOutput getTotal(List<TrechoPedagioOutput> trechosPedagio) {
        final BigDecimal totalBaseCalculo = trechosPedagio.getFirst().getBaseCalculo();
        return TotalPedagioOutput.builder()
                .cbsTotal(totalizaCbs(trechosPedagio, totalBaseCalculo))
                .ibsEstadualTotal(totalizaIbsEstadual(trechosPedagio, totalBaseCalculo))
                .ibsMunicipalTotal(totalizaIbsMunicipal(trechosPedagio, totalBaseCalculo))
                .build();
    }

}
