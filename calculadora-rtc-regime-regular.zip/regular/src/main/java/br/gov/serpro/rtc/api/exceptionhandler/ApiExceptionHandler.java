/*
 * Versão de Homologação/Testes
 */
package br.gov.serpro.rtc.api.exceptionhandler;

import java.time.Instant;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import br.gov.serpro.rtc.api.exceptionhandler.enumeration.ProblemType;
import br.gov.serpro.rtc.domain.service.exception.CampoInvalidoException;
import br.gov.serpro.rtc.domain.service.exception.EntidadeNaoEncontradaException;
import br.gov.serpro.rtc.domain.service.exception.ErroInternoSistemaException;
import br.gov.serpro.rtc.domain.service.exception.EstruturaInconsistenteException;
import br.gov.serpro.rtc.domain.service.exception.PlataformaDownloadNaoEncontradaException;
import br.gov.serpro.rtc.domain.service.exception.ValidacaoException;
import lombok.extern.slf4j.Slf4j;

/**
 * Handler global de exceções da API que traduz erros de validação, negócio e
 * falhas internas para respostas {@link ProblemDetail}.
 *
 * Também ajusta o nível de log conforme a natureza do erro e padroniza o
 * payload retornado aos clientes.
 */
@Slf4j
@RestControllerAdvice
public class ApiExceptionHandler extends ResponseEntityExceptionHandler {
    
    @Override
    protected ResponseEntity<Object> handleExceptionInternal(@NonNull Exception ex, @Nullable Object body, @NonNull HttpHeaders headers,
            @NonNull HttpStatusCode statusCode, @NonNull WebRequest request) {
        
        // Estratégia simples: apenas erros 500+ são logados como ERROR (erros reais)
        // Erros 400-499 são comportamento esperado (erros de negócio/validação)
        if (statusCode.is5xxServerError()) {
            // Erro real do sistema - log completo para análise
            log.error("Erro interno: ", ex);
        } else {
            // Erro de negócio/validação - log simples sem stacktrace
            log.debug("Erro cliente [{}]: {} | URI: {}",
                     statusCode.value(), 
                     ex.getMessage(), 
                     request.getDescription(false));
        }
        
        return super.handleExceptionInternal(ex, body, headers, statusCode, request);
    }
    
    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(
            HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        ProblemDetail problemDetail = createProblem(ex, httpStatus);
        problemDetail.setDetail(ex.getLocalizedMessage());
        return handleExceptionInternal(ex, problemDetail, headers, httpStatus, request);
    }
    
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<Object> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException ex, WebRequest request) {
        HttpStatus status = HttpStatus.BAD_REQUEST;
        ProblemDetail problemDetail = createProblem(ex, status);
        problemDetail.setDetail(String.format("Parâmetro inválido [%s: %s] ", ex.getPropertyName(), ex.getValue()));        
        return handleExceptionInternal(ex, problemDetail, new HttpHeaders(), status, request);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(@NonNull MethodArgumentNotValidException ex,
            @NonNull HttpHeaders headers, @NonNull HttpStatusCode status, @NonNull WebRequest request) {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        
        // Log sucinto para validação - sem stacktrace
        log.debug("Validação falhou: {} campos inválidos | URI: {}",
                 ex.getBindingResult().getErrorCount(),
                 request.getDescription(false));
        
        ProblemDetail problemDetail = createProblem(ex, httpStatus);
        problemDetail.setTitle("Campos inválidos.");
        StringBuilder detailMessage = new StringBuilder("Um ou mais campos são inválidos - ");
        ex.getBindingResult().getFieldErrors().forEach(error -> 
            detailMessage.append(String.format("[%s: %s] ", error.getField(), error.getDefaultMessage()))
        );
        problemDetail.setDetail(detailMessage.toString());
        return handleExceptionInternal(ex, problemDetail, headers, httpStatus, request);
    }

    @ExceptionHandler(ValidacaoException.class)
    ResponseEntity<Object> handleNegocioException(ValidacaoException ex, WebRequest request) {
        HttpStatus status = HttpStatus.UNPROCESSABLE_ENTITY;
        ProblemDetail problemDetail = createProblem(ex, status);
        return handleExceptionInternal(ex, problemDetail, new HttpHeaders(), status, request);
    }

    @ExceptionHandler(CampoInvalidoException.class)
    ResponseEntity<Object> handleCampoInvalidoException(CampoInvalidoException ex, WebRequest request) {
        HttpStatus status = HttpStatus.BAD_REQUEST;
        ProblemDetail problemDetail = createProblem(ex, status);
        return handleExceptionInternal(ex, problemDetail, new HttpHeaders(), status, request);
    }

    @ExceptionHandler(EntidadeNaoEncontradaException.class)
    public ResponseEntity<Object> handleEntidadeNaoEncontradaException(EntidadeNaoEncontradaException ex,
            WebRequest request) {
        HttpStatus status = HttpStatus.NOT_FOUND;
        ProblemDetail problemDetail = createProblem(ex, status);
        return handleExceptionInternal(ex, problemDetail, new HttpHeaders(), status, request);
    }

    @ExceptionHandler(PlataformaDownloadNaoEncontradaException.class)
    public ResponseEntity<Object> handlePlataformaDownloadNaoEncontradaException(
            PlataformaDownloadNaoEncontradaException ex, WebRequest request) {
        HttpStatus status = HttpStatus.NOT_FOUND;
        ProblemDetail problemDetail = createProblem(ex, status);
        return handleExceptionInternal(ex, problemDetail, new HttpHeaders(), status, request);
    }

    @ExceptionHandler(EstruturaInconsistenteException.class)
    ResponseEntity<Object> handleEstruturaInconsistenteException(EstruturaInconsistenteException ex,
            WebRequest request) {
        HttpStatus status = HttpStatus.BAD_REQUEST;
        
        // Estrutura inconsistente - pode ser suspeito, usar WARN
        log.warn("Estrutura inválida: {} | URI: {}", ex.getMessage(), request.getDescription(false));
        
        ProblemDetail problemDetail = createProblem(ex, status);
        return handleExceptionInternal(ex, problemDetail, new HttpHeaders(), status, request);
    }

    @ExceptionHandler(ErroInternoSistemaException.class)
    ResponseEntity<Object> handleErroInternoSistemaException(ErroInternoSistemaException ex, WebRequest request) {
        return handleGenericException(ex, request);
    }

    @ExceptionHandler(Exception.class)
    ResponseEntity<Object> handleGenericException(Exception ex, WebRequest request) {
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        ProblemDetail problemDetail = createProblem(ex, status);
        return handleExceptionInternal(ex, problemDetail, new HttpHeaders(), status, request);
    }

    private static <E extends Exception> ProblemDetail createProblem(E ex, HttpStatus status) {
        ProblemType type = ProblemType.from(ex);
        ProblemDetail problemDetail = ProblemDetail.forStatusAndDetail(status, ex.getMessage());
        problemDetail.setType(type.getURI());
        problemDetail.setTitle(type.getTitulo());
        problemDetail.setProperty("timestamp", Instant.now());
        return problemDetail;
    }

}
