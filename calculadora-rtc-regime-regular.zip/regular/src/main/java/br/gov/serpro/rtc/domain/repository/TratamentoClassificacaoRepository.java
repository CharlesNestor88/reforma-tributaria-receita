/*
 * Versão de Homologação/Testes
 */
package br.gov.serpro.rtc.domain.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.gov.serpro.rtc.domain.model.dto.TratamentoClassificacaoDTO;
import br.gov.serpro.rtc.domain.model.entity.TratamentoClassificacao;

/**
 * Repositório Spring Data JPA central para consultas de vínculo entre
 * classificação tributária e tratamento tributário. Dá suporte à recuperação de
 * regras de tributação, situações tributárias, validações para DF-e e
 * relatórios usados pela calculadora.
 */
public interface TratamentoClassificacaoRepository extends JpaRepository<TratamentoClassificacao, Long> {

    /*
     * Entradas recomendadas na cache: 400
     * Memória estimada: ~49 KB
     */
    @Query("""
            SELECT new br.gov.serpro.rtc.domain.model.dto.TratamentoClassificacaoDTO(
                t.tratamentoTributario.id,
                t.classificacaoTributaria.id,
                t.tratamentoTributario.inIncompativelComSuspensao,
                t.tratamentoTributario.inExigeGrupoDesoneracao)
            FROM TratamentoClassificacao t
            WHERE t.classificacaoTributaria.id = :idClassificacaoTributaria
                AND (t.inicioVigencia <= :data AND (t.fimVigencia IS NULL OR t.fimVigencia >= :data))
            """)
    @Cacheable(cacheNames = "TratamentoClassificacaoRepository.buscarTratamentoClassificacao")
    TratamentoClassificacaoDTO buscarTratamentoClassificacao(Long idClassificacaoTributaria, LocalDate data);

    @Query(value = """
            SELECT
                ct.CLTR_CD,
                ct.CLTR_DESCRICAO,
                ct.CLTR_TIPO_ALIQUOTA,
                ct.CLTR_NOMENCLATURA,
                tt.TRTR_DESCRICAO,
                tt.TRTR_IN_INCOMPATIVEL_COM_SUSPENSAO,
                tt.TRTR_IN_EXIGE_GRUPO_DESONERACAO,
                st.SITR_IND_GRED,
                ct.CLTR_ID,
                ct.CLTR_DATA_ATUALIZACAO
            FROM TRATAMENTO_CLASSIFICACAO tc
            JOIN CLASSIFICACAO_TRIBUTARIA ct ON tc.TRCL_CLTR_ID = ct.CLTR_ID
            JOIN SITUACAO_TRIBUTARIA st ON st.SITR_ID = ct.CLTR_SITR_ID
            JOIN TRATAMENTO_TRIBUTARIO tt ON tt.TRTR_ID = tc.TRCL_TRTR_ID
            WHERE ct.CLTR_SITR_ID = :idSituacaoTributaria
                AND :data BETWEEN tc.TRCL_INICIO_VIGENCIA AND COALESCE(tc.TRCL_FIM_VIGENCIA, :data)
                AND :data BETWEEN ct.CLTR_INICIO_VIGENCIA AND COALESCE(ct.CLTR_FIM_VIGENCIA, :data)
                AND :data BETWEEN tt.TRTR_INICIO_VIGENCIA AND COALESCE(tt.TRTR_FIM_VIGENCIA, :data)
                AND :data BETWEEN st.SITR_INICIO_VIGENCIA AND COALESCE(st.SITR_FIM_VIGENCIA, :data)
            ORDER BY ct.CLTR_CD
            """, nativeQuery = true)
    List<Object[]> consultarTratamentoClassificacaoPorIdSituacaoTributaria(Long idSituacaoTributaria, LocalDate data);

    @Query(value = """
            SELECT
                ct.CLTR_ID,
                ct.CLTR_CD,
                ct.CLTR_DESCRICAO,
                ct.CLTR_TIPO_ALIQUOTA,
                ct.CLTR_NOMENCLATURA,
                tt.TRTR_DESCRICAO,
                tt.TRTR_IN_INCOMPATIVEL_COM_SUSPENSAO,
                tt.TRTR_IN_EXIGE_GRUPO_DESONERACAO,
                st.SITR_IND_GRED,
                ct.CLTR_IN_APROPRIACAO_CREDITOS_ADQUIRENTES_CBS,
                ct.CLTR_IN_APROPRIACAO_CREDITOS_ADQUIRENTES_IBS,
                ct.CLTR_IN_CREDITO_PRESUMIDO_FORNECEDOR,
                ct.CLTR_IN_CREDITO_PRESUMIDO_ADQUIRENTE,
                ct.CLTR_CREDITO_OPERACAO_ANTECEDENTE,
                -- Percentual de redução por tributo
                pr_cbs.PERE_VALOR AS PERCENTUAL_REDUCAO_CBS,
                pr_ibsuf.PERE_VALOR AS PERCENTUAL_REDUCAO_IBSUF,
                pr_ibsmun.PERE_VALOR AS PERCENTUAL_REDUCAO_IBSMUN,
                -- Dados novos da situação tributária
                st.SITR_IND_GDIF,
                ct.CLTR_DATA_ATUALIZACAO,
                ct.CLTR_TPRBSN
            FROM TRATAMENTO_CLASSIFICACAO tc
            JOIN CLASSIFICACAO_TRIBUTARIA ct ON tc.TRCL_CLTR_ID = ct.CLTR_ID
            JOIN SITUACAO_TRIBUTARIA st ON st.SITR_ID = ct.CLTR_SITR_ID
            JOIN TRATAMENTO_TRIBUTARIO tt ON tt.TRTR_ID = tc.TRCL_TRTR_ID
            JOIN TRIBUTO_SITUACAO_TRIBUTARIA tst ON tst.TRST_SITR_ID = ct.CLTR_SITR_ID
            -- LEFT JOINs para percentuais de redução por tributo
            LEFT JOIN PERCENTUAL_REDUCAO pr_cbs ON pr_cbs.PERE_CLTR_ID = ct.CLTR_ID 
                AND pr_cbs.PERE_TBTO_ID = 2 -- CBS
                AND :data BETWEEN pr_cbs.PERE_INICIO_VIGENCIA AND COALESCE(pr_cbs.PERE_FIM_VIGENCIA, :data)
            LEFT JOIN PERCENTUAL_REDUCAO pr_ibsuf ON pr_ibsuf.PERE_CLTR_ID = ct.CLTR_ID 
                AND pr_ibsuf.PERE_TBTO_ID = 3 -- IBSUF
                AND :data BETWEEN pr_ibsuf.PERE_INICIO_VIGENCIA AND COALESCE(pr_ibsuf.PERE_FIM_VIGENCIA, :data)
            LEFT JOIN PERCENTUAL_REDUCAO pr_ibsmun ON pr_ibsmun.PERE_CLTR_ID = ct.CLTR_ID 
                AND pr_ibsmun.PERE_TBTO_ID = 4 -- IBSMun
                AND :data BETWEEN pr_ibsmun.PERE_INICIO_VIGENCIA AND COALESCE(pr_ibsmun.PERE_FIM_VIGENCIA, :data)
            WHERE :data BETWEEN tc.TRCL_INICIO_VIGENCIA AND COALESCE(tc.TRCL_FIM_VIGENCIA, :data)
              AND :data BETWEEN ct.CLTR_INICIO_VIGENCIA AND COALESCE(ct.CLTR_FIM_VIGENCIA, :data)
              AND :data BETWEEN tt.TRTR_INICIO_VIGENCIA AND COALESCE(tt.TRTR_FIM_VIGENCIA, :data)
              AND :data BETWEEN tst.TRST_INICIO_VIGENCIA AND COALESCE(tst.TRST_FIM_VIGENCIA, :data)
              AND tst.TRST_TBTO_ID == 2
              AND (:codigo IS NULL OR ct.CLTR_CD = :codigo)
            ORDER BY ct.CLTR_CD
            """, nativeQuery = true)
    List<Object[]> consultarTratamentoClassificacaoCbsIbs(
        @Param("codigo") String codigo,
        @Param("data") LocalDate data);
    
    @Cacheable(cacheNames = "TratamentoClassificacaoRepository.consultarValidadeDfeClassificacaoTributaria")
    @Query(value = """
        SELECT
            ct.CLTR_ID, ----------------------------- [0] idClassificacaoTributaria
            ct.CLTR_NOMENCLATURA, ------------------- [1] nomenclatura
            tt.TRTR_IN_EXIGE_GRUPO_DESONERACAO, ----- [2] exigeGrupoTributacaoRegular
            st.SITR_IND_GDIF, ----------------------- [3] permiteDiferimento
            ct.CLTR_IND_GCREDPRESOPER, -------------- [4] possibilidadeCreditoPresumido
            st.SITR_IND_GIBSCBS --------------------- [5] exigeGrupoIbsCbs
        FROM TRATAMENTO_CLASSIFICACAO tc
        INNER JOIN CLASSIFICACAO_TRIBUTARIA ct ON tc.TRCL_CLTR_ID = ct.CLTR_ID
            AND :data BETWEEN ct.CLTR_INICIO_VIGENCIA AND COALESCE(ct.CLTR_FIM_VIGENCIA, :data)
        INNER JOIN SITUACAO_TRIBUTARIA st ON st.SITR_ID = ct.CLTR_SITR_ID
            AND :data BETWEEN st.SITR_INICIO_VIGENCIA AND COALESCE(st.SITR_FIM_VIGENCIA, :data)
        INNER JOIN TRATAMENTO_TRIBUTARIO tt ON tt.TRTR_ID = tc.TRCL_TRTR_ID
            AND :data BETWEEN tt.TRTR_INICIO_VIGENCIA AND COALESCE(tt.TRTR_FIM_VIGENCIA, :data)
        INNER JOIN TRIBUTO_SITUACAO_TRIBUTARIA tst ON tst.TRST_SITR_ID = st.SITR_ID
            AND tst.TRST_TBTO_ID = 2
            AND :data BETWEEN tst.TRST_INICIO_VIGENCIA AND COALESCE(tst.TRST_FIM_VIGENCIA, :data)
        WHERE ct.CLTR_CD = :codigoClassificacaoTributaria
          AND :data BETWEEN tc.TRCL_INICIO_VIGENCIA AND COALESCE(tc.TRCL_FIM_VIGENCIA, :data)
        LIMIT 1
        """, nativeQuery = true)
    Object[] consultarValidadeDfeClassificacaoTributaria(String codigoClassificacaoTributaria, LocalDate data);

    @Query(value = """
            SELECT
                ct.CLTR_ID,
                ct.CLTR_CD,
                ct.CLTR_DESCRICAO,
                ct.CLTR_TIPO_ALIQUOTA,
                ct.CLTR_NOMENCLATURA,
                tt.TRTR_DESCRICAO,
                tt.TRTR_IN_INCOMPATIVEL_COM_SUSPENSAO,
                tt.TRTR_IN_EXIGE_GRUPO_DESONERACAO,
                st.SITR_IND_GRED,
                tt.TRTR_IN_POSSUI_PERCENTUAL_REDUCAO,
                st.SITR_IND_GDIF,
                ct.CLTR_DATA_ATUALIZACAO
            FROM TRATAMENTO_CLASSIFICACAO tc
            JOIN CLASSIFICACAO_TRIBUTARIA ct ON tc.TRCL_CLTR_ID = ct.CLTR_ID
            JOIN SITUACAO_TRIBUTARIA st ON st.SITR_ID = ct.CLTR_SITR_ID
            JOIN TRATAMENTO_TRIBUTARIO tt ON tt.TRTR_ID = tc.TRCL_TRTR_ID
            JOIN TRIBUTO_SITUACAO_TRIBUTARIA tst ON tst.TRST_SITR_ID = ct.CLTR_SITR_ID
            WHERE :data BETWEEN tc.TRCL_INICIO_VIGENCIA AND COALESCE(tc.TRCL_FIM_VIGENCIA, :data)
              AND :data BETWEEN ct.CLTR_INICIO_VIGENCIA AND COALESCE(ct.CLTR_FIM_VIGENCIA, :data)
              AND :data BETWEEN tt.TRTR_INICIO_VIGENCIA AND COALESCE(tt.TRTR_FIM_VIGENCIA, :data)
              AND :data BETWEEN tst.TRST_INICIO_VIGENCIA AND COALESCE(tst.TRST_FIM_VIGENCIA, :data)
              AND :data BETWEEN st.SITR_INICIO_VIGENCIA AND COALESCE(st.SITR_FIM_VIGENCIA, :data)
              AND tst.TRST_TBTO_ID == 1
              AND (:codigo IS NULL OR ct.CLTR_CD = :codigo)
            ORDER BY ct.CLTR_CD
            """, nativeQuery = true)
    List<Object[]> consultarTratamentoClassificacaoImpostoSeletivo(
        @Param("codigo") String codigo,
        @Param("data") LocalDate data);

    @Query(value = """
            SELECT
                ct.CLTR_CD,
                ct.CLTR_DESCRICAO,
                ct.CLTR_TIPO_ALIQUOTA,
                ct.CLTR_NOMENCLATURA,
                tt.TRTR_DESCRICAO,
                tt.TRTR_IN_INCOMPATIVEL_COM_SUSPENSAO,
                tt.TRTR_IN_EXIGE_GRUPO_DESONERACAO,
                st.SITR_IND_GRED,
                ct.CLTR_ID,
                ct.CLTR_DATA_ATUALIZACAO
            FROM TRATAMENTO_CLASSIFICACAO tc
            JOIN CLASSIFICACAO_TRIBUTARIA ct ON tc.TRCL_CLTR_ID = ct.CLTR_ID
            JOIN SITUACAO_TRIBUTARIA st ON st.SITR_ID = ct.CLTR_SITR_ID
            JOIN TRATAMENTO_TRIBUTARIO tt ON tt.TRTR_ID = tc.TRCL_TRTR_ID
            WHERE st.SITR_CD = :cst
              AND EXISTS (
                  SELECT 1 FROM TRIBUTO_SITUACAO_TRIBUTARIA tst2 
                  JOIN TRIBUTO tb2 ON tst2.TRST_TBTO_ID = tb2.TBTO_ID
                  WHERE tst2.TRST_SITR_ID = st.SITR_ID
                  AND tb2.TBTO_SIGLA IN (:tbtoSiglas)
                  AND :data BETWEEN tst2.TRST_INICIO_VIGENCIA AND COALESCE(tst2.TRST_FIM_VIGENCIA, :data)
                  AND :data BETWEEN tb2.TBTO_INICIO_VIGENCIA AND COALESCE(tb2.TBTO_FIM_VIGENCIA, :data)
              )
              AND :data BETWEEN tc.TRCL_INICIO_VIGENCIA AND COALESCE(tc.TRCL_FIM_VIGENCIA, :data)
              AND :data BETWEEN ct.CLTR_INICIO_VIGENCIA AND COALESCE(ct.CLTR_FIM_VIGENCIA, :data)
              AND :data BETWEEN tt.TRTR_INICIO_VIGENCIA AND COALESCE(tt.TRTR_FIM_VIGENCIA, :data)
              AND :data BETWEEN st.SITR_INICIO_VIGENCIA AND COALESCE(st.SITR_FIM_VIGENCIA, :data)
            ORDER BY ct.CLTR_CD
            """, nativeQuery = true)
    List<Object[]> consultarTratamentoClassificacaoPorCstETributoTipo(
            String cst,
            List<String> tbtoSiglas,
            LocalDate data
    );

}
