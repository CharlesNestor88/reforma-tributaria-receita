package br.gov.serpro.rtc.api.model.roc;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;
import static java.math.BigDecimal.ZERO;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import tools.jackson.databind.annotation.JsonSerialize;

import br.gov.serpro.rtc.api.model.SerializationVisibility;
import br.gov.serpro.rtc.config.serializer.BigDecimalTDec0302_04Serializer;
import br.gov.serpro.rtc.config.serializer.BigDecimalTDec1302Serializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

/**
 * Representa a apuração do IBS de competência da UF no item, com alíquota,
 * diferimento, devolução, redução, valor devido e memória de cálculo.
 */
@Getter
@Setter
@JsonInclude(NON_NULL)
@JsonPropertyOrder({ "pIBSUF", "gDif", "gDevTrib", "gRed", "vIBSUF" })
public class IBSUFDomain implements SerializationVisibility {
    
    @JsonSerialize(using = BigDecimalTDec0302_04Serializer.class)
    @Schema(description = "Alíquota do IBS de competência das UF")
    private BigDecimal pIBSUF = ZERO;
    
    @Schema(description = "Grupo de Informações do Diferimento")
    private DiferimentoDomain gDif;

    @Schema(description = "Grupo de Informações da devolução de tributos")
    private DevolucaoTributosDomain gDevTrib;

    @Schema(description = "Grupo de Informações da redução da alíquota")
    private ReducaoAliquotaDomain gRed;

    @JsonSerialize(using = BigDecimalTDec1302Serializer.class)
    @Schema(description = "Valor do IBS de competência da UF")
    private BigDecimal vIBSUF = ZERO;
    
    @JsonIgnore
    public BigDecimal getVDif() {
        return getGDif() != null ? getGDif().getVDif() : ZERO;
    }

    @JsonIgnore
    public BigDecimal getVDevTrib() {
        return getGDevTrib() != null ? getGDevTrib().getVDevTrib() : ZERO;
    }

}