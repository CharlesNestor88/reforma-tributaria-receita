package br.gov.serpro.rtc.shared.serializer;

import static java.time.LocalDate.parse;
import static java.time.format.DateTimeFormatter.ISO_LOCAL_DATE;

import java.time.LocalDate;

import org.springframework.stereotype.Component;

import tools.jackson.core.JsonParser;
import tools.jackson.databind.DeserializationContext;
import tools.jackson.databind.ValueDeserializer;

import lombok.extern.slf4j.Slf4j;

/**
 * Deserializa valores de {@link LocalDate} no formato ISO yyyy-MM-dd com
 * validação prévia.
 */
@Slf4j
@Component
public final class LocalDateCustomDeserializer extends ValueDeserializer<LocalDate> {
    private static final String DATE_PATTERN = "\\d{4}-\\d{2}-\\d{2}";
    private static final String FORMAT = "yyyy-MM-dd";
    private static final String VALID_EXAMPLE = "2026-01-05";
    
    private static final ValueDeserializer<LocalDate> INSTANCE =     
            new GenericCustomDeserializer<>(
                    DATE_PATTERN,
                    FORMAT,
                    VALID_EXAMPLE,
                    value -> parse(value, ISO_LOCAL_DATE),
                    LocalDate.class
                );
    
    @Override
    public LocalDate deserialize(JsonParser p, DeserializationContext ctxt) {
        return INSTANCE.deserialize(p, ctxt);
    }
    
    @Override
    public ValueDeserializer<?> getDelegatee() {
        return INSTANCE;
    }

}